package com.asimkilic.n11.n11bootcamp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class N11BootcampApplication {

	public static void main(String[] args) {
		SpringApplication.run(N11BootcampApplication.class, args);
	}

}
