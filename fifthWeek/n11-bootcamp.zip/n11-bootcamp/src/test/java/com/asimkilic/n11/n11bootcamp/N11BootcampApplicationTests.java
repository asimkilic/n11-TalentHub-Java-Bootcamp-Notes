package com.asimkilic.n11.n11bootcamp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class N11BootcampApplicationTests {

	@Test
	void contextLoads() {
	}

}
